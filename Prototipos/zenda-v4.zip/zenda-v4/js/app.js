(function () {
  'use strict';

  // ── TEMA ────────────────────────────────────
  var THEME_KEY = 'zenda_theme';

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(THEME_KEY, theme);
    var btn = document.getElementById('themeToggle');
    if (btn) {
      btn.innerHTML = theme === 'dark'
        ? '<i class="bi bi-sun"></i>'
        : '<i class="bi bi-moon"></i>';
      btn.title = theme === 'dark' ? 'Modo claro' : 'Modo oscuro';
    }
  }

  var savedTheme = localStorage.getItem(THEME_KEY) || 'dark';
  applyTheme(savedTheme);

  document.addEventListener('DOMContentLoaded', function () {
    applyTheme(savedTheme);

    var toggleBtn = document.getElementById('themeToggle');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', function () {
        var current = document.documentElement.getAttribute('data-theme');
        applyTheme(current === 'dark' ? 'light' : 'dark');
      });
    }

    // ── SIDEBAR ────────────────────────────────
    var sidebar   = document.getElementById('sidebar');
    var overlay   = document.getElementById('overlay');
    var hamburger = document.getElementById('hamburger');

    function openSidebar() {
      if (!sidebar) return;
      sidebar.classList.add('open');
      if (overlay) overlay.classList.add('show');
      document.body.style.overflow = 'hidden';
    }
    function closeSidebar() {
      if (!sidebar) return;
      sidebar.classList.remove('open');
      if (overlay) overlay.classList.remove('show');
      document.body.style.overflow = '';
    }

    if (hamburger) hamburger.addEventListener('click', function () {
      sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    });
    if (overlay) overlay.addEventListener('click', closeSidebar);

    // Nav activo
    var currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-item[data-page]').forEach(function (link) {
      if (link.dataset.page === currentPage) {
        document.querySelectorAll('.nav-item').forEach(function (l) { l.classList.remove('active'); });
        link.classList.add('active');
      }
    });

    // ── MODALES ────────────────────────────────
    document.querySelectorAll('[data-modal-open]').forEach(function (btn) {
      btn.addEventListener('click', function () { openModal(btn.dataset.modalOpen); });
    });
    document.querySelectorAll('[data-modal-close]').forEach(function (btn) {
      btn.addEventListener('click', function () { closeModal(btn.dataset.modalClose); });
    });
    document.querySelectorAll('.modal-backdrop').forEach(function (bd) {
      bd.addEventListener('click', function (e) {
        if (e.target === bd) closeAllModals();
      });
    });

    // ── DROPDOWNS ──────────────────────────────
    document.querySelectorAll('[data-dropdown]').forEach(function (trigger) {
      trigger.addEventListener('click', function (e) {
        e.stopPropagation();
        var menu = document.getElementById(trigger.dataset.dropdown);
        if (!menu) return;
        var isOpen = menu.classList.contains('show');
        closeAllDropdowns();
        if (!isOpen) menu.classList.add('show');
      });
    });
    document.addEventListener('click', closeAllDropdowns);

    // ── TABS ───────────────────────────────────
    document.querySelectorAll('[data-tabs]').forEach(function (group) {
      var name   = group.dataset.tabs;
      var tabs   = group.querySelectorAll('.tab');
      var panels = document.querySelectorAll('.tab-panel[data-tab-group="' + name + '"]');
      tabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
          tabs.forEach(function (t) { t.classList.remove('active'); });
          panels.forEach(function (p) { p.classList.remove('active'); });
          tab.classList.add('active');
          var target = document.querySelector('.tab-panel[data-tab-group="' + name + '"][data-tab="' + tab.dataset.tab + '"]');
          if (target) target.classList.add('active');
        });
      });
    });

    // ── TOGGLE PASSWORD ────────────────────────
    document.querySelectorAll('.toggle-password').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var input = document.querySelector(btn.dataset.target);
        if (!input) return;
        var isText = input.type === 'text';
        input.type = isText ? 'password' : 'text';
        btn.querySelector('i').className = isText ? 'bi bi-eye' : 'bi bi-eye-slash';
      });
    });

    // ── PROGRESS BARS ──────────────────────────
    document.querySelectorAll('.progress-fill[data-w]').forEach(function (bar) {
      var obs = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            bar.style.width = bar.dataset.w + '%';
            obs.unobserve(bar);
          }
        });
      }, { threshold: 0.2 });
      bar.style.width = '0%';
      obs.observe(bar);
    });

    // ── ESC ────────────────────────────────────
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { closeSidebar(); closeAllModals(); closeAllDropdowns(); }
    });
  });

  // ── FUNCIONES GLOBALES ──────────────────────
  window.openModal = function (id) {
    var m = document.getElementById(id);
    if (m) { m.classList.add('show'); document.body.style.overflow = 'hidden'; }
  };
  window.closeModal = function (id) {
    var m = document.getElementById(id);
    if (m) { m.classList.remove('show'); document.body.style.overflow = ''; }
  };

  function closeAllModals() {
    document.querySelectorAll('.modal-backdrop.show').forEach(function (m) { m.classList.remove('show'); });
    document.body.style.overflow = '';
  }
  function closeAllDropdowns() {
    document.querySelectorAll('.dropdown-menu.show').forEach(function (d) { d.classList.remove('show'); });
  }

  window.toast = function (msg, type, duration) {
    type = type || 'success';
    duration = duration || 3000;
    var icons = { success: 'bi-check-circle-fill', error: 'bi-x-circle-fill', warn: 'bi-exclamation-triangle-fill', info: 'bi-info-circle-fill' };
    var container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    var el = document.createElement('div');
    el.className = 'toast ' + type;
    el.innerHTML = '<i class="bi ' + (icons[type] || icons.info) + ' ti"></i><span>' + msg + '</span>';
    container.appendChild(el);
    setTimeout(function () {
      el.style.opacity = '0';
      el.style.transform = 'translateY(6px)';
      el.style.transition = 'all .25s ease';
      setTimeout(function () { el.remove(); }, 280);
    }, duration);
  };

  window.switchPage = function (href) { window.location.href = href; };

})();
