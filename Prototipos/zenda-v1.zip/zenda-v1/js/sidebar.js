(function () {
  'use strict';

  const sidebar  = document.getElementById('sidebar');
  const overlay  = document.getElementById('sidebarOverlay');
  const hamburger = document.getElementById('hamburger');

  if (!sidebar) return;

  function openSidebar() {
    sidebar.classList.add('open');
    if (overlay) overlay.classList.add('show');
    document.body.style.overflow = 'hidden';
  }

  function closeSidebar() {
    sidebar.classList.remove('open');
    if (overlay) overlay.classList.remove('show');
    document.body.style.overflow = '';
  }

  if (hamburger) {
    hamburger.addEventListener('click', () => {
      sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    });
  }

  if (overlay) {
    overlay.addEventListener('click', closeSidebar);
  }

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeSidebar();
  });

  const links = sidebar.querySelectorAll('.nav-link-z');
  const currentPage = window.location.pathname.split('/').pop() || 'dashboard.html';

  links.forEach(link => {
    const href = link.getAttribute('href');
    if (href && href === currentPage) {
      links.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
    }
  });

})();
