(function () {
  'use strict';

  function animateProgressBars() {
    const bars = document.querySelectorAll('.progress-z-bar[data-width]');
    if (!bars.length) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const bar = entry.target;
          bar.style.width = bar.dataset.width + '%';
          observer.unobserve(bar);
        }
      });
    }, { threshold: 0.3 });

    bars.forEach(bar => {
      bar.style.width = '0%';
      observer.observe(bar);
    });
  }

  function initNotifDismiss() {
    document.querySelectorAll('.notif-row[data-dismiss]').forEach(row => {
      row.style.cursor = 'pointer';
      row.addEventListener('click', () => {
        row.style.transition = 'opacity .3s, transform .3s';
        row.style.opacity = '0';
        row.style.transform = 'translateX(20px)';
        setTimeout(() => row.remove(), 300);
      });
    });
  }

  function initTooltips() {
    if (typeof bootstrap !== 'undefined') {
      document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
        new bootstrap.Tooltip(el);
      });
    }
  }

  function initClock() {
    const clockEl = document.getElementById('topbarClock');
    if (!clockEl) return;

    function updateClock() {
      const now = new Date();
      const h = String(now.getHours()).padStart(2, '0');
      const m = String(now.getMinutes()).padStart(2, '0');
      clockEl.textContent = `${h}:${m}`;
    }

    updateClock();
    setInterval(updateClock, 60000);
  }

  document.addEventListener('DOMContentLoaded', () => {
    animateProgressBars();
    initNotifDismiss();
    initTooltips();
    initClock();
  });

})();
